/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javax.swing.*;
/**
 *
 * @author Ing. Angel Mendoza
 */
public class Principal {
    public static void main (String [] args){
        int max=0;
        
        max = Integer.parseInt( JOptionPane.showInputDialog("¿Cuantos contactos decesas tener?") );
        
        Menu_p mp = new Menu_p();
        mp.inicialisaCola(max);
        mp.setVisible(true);
        mp.setLocationRelativeTo(null);
    }
    
}
