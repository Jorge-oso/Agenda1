
import javax.swing.JOptionPane;

public class Menu_p extends javax.swing.JFrame {
    private int max;
    ColaCircular cola; 

    public Menu_p() {
        initComponents();
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        AGC = new javax.swing.JFrame();
        jPanel3 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        Nombre1 = new javax.swing.JTextField();
        APM1 = new javax.swing.JTextField();
        APP1 = new javax.swing.JTextField();
        Tel1 = new javax.swing.JTextField();
        Correo1 = new javax.swing.JTextField();
        Direccion1 = new javax.swing.JTextField();
        Agregar_interfaz_de_con = new javax.swing.JButton();
        Cancelar_de_IdeC = new javax.swing.JButton();
        IMPC = new javax.swing.JFrame();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Contactos = new javax.swing.JTable();
        Elimina_De_tabla = new javax.swing.JButton();
        Buscar = new javax.swing.JFrame();
        jPanel4 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        Contacto = new javax.swing.JTextField();
        BuscarC = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        agregarc = new javax.swing.JButton();
        mostarc = new javax.swing.JButton();
        buscarC_menu = new javax.swing.JButton();
        eliminac = new javax.swing.JButton();

        AGC.setMinimumSize(new java.awt.Dimension(380, 350));

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "Informacion de el Contacto."));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setText("Nombre:");

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setText("Apellido materno:");

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setText("Apellido paterno:");

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel10.setText("Telefono:");

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel11.setText("Correo:");

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel12.setText("Dirección:");

        Nombre1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                Nombre1KeyTyped(evt);
            }
        });

        Tel1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                Tel1KeyTyped(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Nombre1, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(APM1, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(APP1, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Tel1, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Correo1, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Direccion1)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Nombre1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(APM1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(APP1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Tel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Correo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Direccion1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Agregar_interfaz_de_con.setText("Agregar Contacto");
        Agregar_interfaz_de_con.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Agregar_interfaz_de_conActionPerformed(evt);
            }
        });

        Cancelar_de_IdeC.setText("Cancelar");
        Cancelar_de_IdeC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Cancelar_de_IdeCActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout AGCLayout = new javax.swing.GroupLayout(AGC.getContentPane());
        AGC.getContentPane().setLayout(AGCLayout);
        AGCLayout.setHorizontalGroup(
            AGCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(AGCLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(AGCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, AGCLayout.createSequentialGroup()
                        .addComponent(Cancelar_de_IdeC)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(Agregar_interfaz_de_con)))
                .addContainerGap())
        );
        AGCLayout.setVerticalGroup(
            AGCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(AGCLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(AGCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Agregar_interfaz_de_con)
                    .addComponent(Cancelar_de_IdeC))
                .addContainerGap())
        );

        IMPC.setMinimumSize(new java.awt.Dimension(502, 370));

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "Contactos"));

        Contactos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Nombre", "A. Paterno", "A. Materno", "Telefono.", "Correo", "Direccion"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, true, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(Contactos);

        Elimina_De_tabla.setText("Elimina Contacto");
        Elimina_De_tabla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Elimina_De_tablaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(Elimina_De_tabla))
                    .addComponent(jScrollPane1))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Elimina_De_tabla)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout IMPCLayout = new javax.swing.GroupLayout(IMPC.getContentPane());
        IMPC.getContentPane().setLayout(IMPCLayout);
        IMPCLayout.setHorizontalGroup(
            IMPCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(IMPCLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        IMPCLayout.setVerticalGroup(
            IMPCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(IMPCLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        Buscar.setFocusable(false);
        Buscar.setMinimumSize(new java.awt.Dimension(400, 300));

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "Busqueda de contacto:"));

        jLabel1.setText("Nombre a buscar:");

        BuscarC.setText("Buscar");
        BuscarC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BuscarCActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Contacto, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(BuscarC)
                .addContainerGap(72, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(Contacto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BuscarC))
                .addContainerGap(223, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout BuscarLayout = new javax.swing.GroupLayout(Buscar.getContentPane());
        Buscar.getContentPane().setLayout(BuscarLayout);
        BuscarLayout.setHorizontalGroup(
            BuscarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BuscarLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        BuscarLayout.setVerticalGroup(
            BuscarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BuscarLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "Elige una Opción"));

        agregarc.setText("Agregar Contacto.");
        agregarc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agregarcActionPerformed(evt);
            }
        });

        mostarc.setText("Mostrar Contactos.");
        mostarc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mostarcActionPerformed(evt);
            }
        });

        buscarC_menu.setText("Buscar Contacto.");
        buscarC_menu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarC_menuActionPerformed(evt);
            }
        });

        eliminac.setText("Eliminar Contacto.");
        eliminac.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminacActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(87, 87, 87)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(eliminac, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buscarC_menu, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(mostarc, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(agregarc, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(92, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(agregarc, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(mostarc, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(buscarC_menu, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addComponent(eliminac, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    public void inicialisaCola(int max){
        this.max=max;
        cola = new ColaCircular((max+1));
    }
    
    private void agregarcActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agregarcActionPerformed
        AGC.setVisible(true);//para que se muestre la interfaz de agregar contacto
        AGC.setLocationRelativeTo(null);//para que este centrada
    }//GEN-LAST:event_agregarcActionPerformed

    private void Nombre1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Nombre1KeyTyped
        //Campo de texto del nombre
        char x = evt.getKeyChar();
        if((x<'A' || x>'Z') && (x<'a' || x>'z') && (x<'0' || x>'9') && (x<' ' || x>' ') && (x<'.' || x>'.') && (x<'@' || x>'@') && (x<'_' || x>'_'))evt.consume();
    }//GEN-LAST:event_Nombre1KeyTyped

    private void limpiarag(){
        //metodo de limpiar campos
        Nombre1.setText("");
        APM1.setText("");
        APP1.setText("");
        Tel1.setText("");
        Correo1.setText("");
        Direccion1.setText("");
    }
    
    private void Agregar_interfaz_de_conActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Agregar_interfaz_de_conActionPerformed
        //condicion para agregar valores en los campos de texto y guardar
        //equals es un comparador de cadena de caracteres.
        if((Nombre1.getText().equals("") || APM1.getText().equals("")) || (APP1.getText().equals("") || Tel1.getText().equals("")) ||(Correo1.getText().equals("") || Direccion1.getText().equals("")) )
            JOptionPane.showMessageDialog(null, "Por favor llena todos campos para poder continuar" );
        
        //cundo los campos no estan vacios se agrega datoa la tabla
        else{
            String dato = Nombre1.getText()+"_"+APM1.getText()+"_"+APP1.getText()+"_"+Tel1.getText()+"_"+Correo1.getText()+"_"+Direccion1.getText();
            cola.ingresardato(dato);            
                limpiarag();
        }
    }//GEN-LAST:event_Agregar_interfaz_de_conActionPerformed

    private void Cancelar_de_IdeCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Cancelar_de_IdeCActionPerformed
       //cancelacion de un contacto
        AGC.setVisible(false);
    }//GEN-LAST:event_Cancelar_de_IdeCActionPerformed

    private void Tel1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tel1KeyTyped
        // TODO add your handling code here:
        //solo numero permitidos en el campo del telefono
        char x;
        x=evt.getKeyChar();
        
        if((x<'0'||x>'9'))evt.consume();
    }//GEN-LAST:event_Tel1KeyTyped

    private void mostarcActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mostarcActionPerformed
        // TODO add your handling code here:
        //mostrar el contenido llenado en los campos
        int posicion;
        String nombre;
        String app;
        String apm;
        String tel;
        String correo;
        String direc;
        String contactoc;
        
        IMPC.setVisible(true);//para que se muestre la interfaz de imprime contacto
        IMPC. setLocationRelativeTo(null);//para que aparezca centrado
        Elimina_De_tabla.setVisible(false);
        
        //for que rrecore le vector y llena los valores en la tabla de contactos
        for(int i=1;i<=max;i++){
            System.out.println(cola.muestraDato(i));
            contactoc = cola.muestraDato(i);
            //condicion if para el llenado de la tabla con un split
            if(contactoc.length()>1){
                //matriz para que se cumpla la condicon de separamiento
                String partes[] = contactoc.split("_");
                nombre = partes[0];
                app = partes[1];
                apm = partes[2];
                tel = partes[3];
                correo = partes[4];
                direc = partes[5];
                //coordenadas que resivira cada valor en los atributos agregados
                Contactos.setValueAt(nombre, (i-1), 0);
                Contactos.setValueAt(app, (i-1), 1);
                Contactos.setValueAt(apm, (i-1), 2);
                Contactos.setValueAt(tel, (i-1), 3);
                Contactos.setValueAt(correo, (i-1), 4);
                Contactos.setValueAt(direc, (i-1), 5);
            }
        }
    }//GEN-LAST:event_mostarcActionPerformed

    private void BuscarCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BuscarCActionPerformed
        //Metodo para buscar Contacto en la interfaz de buscar
        String mensaje;
        mensaje = cola.bucaContacto(Contacto.getText());
        JOptionPane.showMessageDialog(null, mensaje);
    }//GEN-LAST:event_BuscarCActionPerformed

    private void buscarC_menuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarC_menuActionPerformed
        //Boton de Buscar en el menu.
        Buscar.setVisible(true);//Para mostrar la interfaz de busqueda de contacto
        Buscar.setLocationRelativeTo(null);//para que aparezca centrada
    }//GEN-LAST:event_buscarC_menuActionPerformed

    private void eliminacActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminacActionPerformed
        //Eliminar contacto
        IMPC.setVisible(true);//mostrar la interfaz de eliminar contacto
        IMPC.setLocationRelativeTo(null);//para que aparezaca la interfas centrada
        Elimina_De_tabla.setVisible(true);//boton de eliminacion de la tabla de contactos
    }//GEN-LAST:event_eliminacActionPerformed

    private void Elimina_De_tablaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Elimina_De_tablaActionPerformed
        // TODO add your handling code here:
        //tabla de eliminacion de la interfaz de imprimir contacto
        cola.retirardato();//llamado del metodo retirar contacto
        JOptionPane.showMessageDialog(null,"Contacto eliminado");
    }//GEN-LAST:event_Elimina_De_tablaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Menu_p.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Menu_p.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Menu_p.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Menu_p.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Menu_p().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JFrame AGC;
    private javax.swing.JTextField APM1;
    private javax.swing.JTextField APP1;
    private javax.swing.JButton Agregar_interfaz_de_con;
    private javax.swing.JFrame Buscar;
    private javax.swing.JButton BuscarC;
    private javax.swing.JButton Cancelar_de_IdeC;
    private javax.swing.JTextField Contacto;
    private javax.swing.JTable Contactos;
    private javax.swing.JTextField Correo1;
    private javax.swing.JTextField Direccion1;
    private javax.swing.JButton Elimina_De_tabla;
    private javax.swing.JFrame IMPC;
    private javax.swing.JTextField Nombre1;
    private javax.swing.JTextField Tel1;
    private javax.swing.JButton agregarc;
    private javax.swing.JButton buscarC_menu;
    private javax.swing.JButton eliminac;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton mostarc;
    // End of variables declaration//GEN-END:variables
}
