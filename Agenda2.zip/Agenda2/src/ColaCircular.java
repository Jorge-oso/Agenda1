 
import javax.swing.*;

public class ColaCircular {
    int max;//capacidad de la cola
    final int min = 1;//frente de la cola  
    int longitud; //longitud del la Cola;

    public String[] vector;//vector de la cola circular
    public String[] nombres; //Vector de nombres
    int p;//primero
    int u;//ultimo

    public ColaCircular(int m) {
        //Define la Capacidad
        vector = new String[m];//crea el espacio en la cola
        nombres = new String[m];
        max = vector.length - 1;
        p = 0;//primero
        u = 0;//ultimo
        longitud = m; 
    }

    public void ingresardato(String dato) {
        if ((p == (u + 1)) || (u == max && p == min)) {
            JOptionPane.showMessageDialog(null,"Cola llena (OverFlow)");
        } else {
            if ((p == 0) && (u == 0)) {
                u = min;
                p = min;
                vector[u] = dato;
                String aux[] = dato.split("_");
                nombres[u] = aux[0];
                JOptionPane.showMessageDialog(null,"Contacto agregado");
            } else {
                if (u == max) {
                    u = min;
                    vector[u] = dato;
                    String aux1[] = dato.split("_");
                    nombres[u] = aux1[0];
                    JOptionPane.showMessageDialog(null,"Contacto agregado");
                } else {
                    u = u + 1;
                    vector[u] = dato;
                    String aux2[] = dato.split("_");
                    nombres[u] = aux2[0];
                    JOptionPane.showMessageDialog(null,"Contacto agregado");
                }
            }
        }
    }
//metodo de retirar contacto
    public void retirardato() {
        if ((p == 0) && (u == 0)) {
            JOptionPane.showMessageDialog(null,"Cola vacia (Underflow)");
        } else {
            if (p == u) {
                p = u = 0;
            } else {
                if (p == max) {
                    p = min;
                } else {
                    p = p + 1;
                }
            }
        }
    }
    
    //public void elimna(String contacto){
     //   for(int i=1; i<vector.length;i++){
            //if(nombres[i].equals(contacto)){
            //    vector[i] = "";
          //      JOptionPane.showMessageDialog(null, "Contacto Eliminado");
        //    }
      //  }
    //}
    
    
    public String muestraDato(int j){ //Seder
        String Contacto = vector[j];
        return Contacto;
    }
    
    //metodo de buscar contacto por nombre
    public String bucaContacto(String contacto){
        String informacion;
        for(int i = 1; i < nombres.length; i++){
            if(nombres[i].equals(contacto)){
                informacion =  muestraDato(i);
                return informacion;
            }
        }
        return "No se encontro el contacto \" "+contacto+"\" ";
    }    
}
